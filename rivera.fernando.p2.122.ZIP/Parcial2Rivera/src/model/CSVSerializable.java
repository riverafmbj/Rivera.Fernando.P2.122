
package model;

@FunctionalInterface
public interface CSVSerializable {
    
    String toCSV();
}
