
package model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;


public class ColeccionPersonajes <T extends CSVSerializable> implements Iterable<T>, Serializable{
    
    private List<T> inventario;
    
    public ColeccionPersonajes(){
        inventario = new ArrayList<>();
    }
    
    public void agregar(T personaje){
        inventario.add(personaje);
    }
    
    public void eliminar(int indice){
        validarIndice(indice);
        inventario.remove(indice);
    }
    
    public T obtener(int indice){
        validarIndice(indice);
        return inventario.get(indice);
    }
    
    
    public void ordenar(){
        this.forEach(System.out::println);
    }
    
    public void ordenar(Comparator<? super T> comparator){
        inventario.sort(comparator);
    }
    
    @Override
    public Iterator<T> iterator(){
        
        List<T> copia = copiarInventario();
        
        if(!copia.isEmpty() && copia.get(0) instanceof Comparable){
            Collections.sort((List<? extends Comparable>) copia);
        }
        return copia.iterator();
    }
    
    public Iterator<T> iterator(Comparator<? super T> c){
        
        List<T> copia = copiarInventario();
        copia.sort(c);
        
        return copia.iterator();
    }
    
    public List<T> filtrar(Predicate<? super T> criterio){
        List<T> nuevaLista = new ArrayList<>();
        for(T e: inventario){
            if(criterio.test(e)){
                nuevaLista.add(e);
            }
        }
        return nuevaLista;
    }
    
    public void paraCadaElemento(Consumer<? super T> accion){
        List<T> copia = copiarInventario();
        for(T e: copia){
            accion.accept(e);
        }
    }
    
    private List<T> copiarInventario(){
        return new ArrayList<>(inventario);
    }
    
    private void validarIndice(int indice){
        if(indice < 0 || indice > inventario.size()){
            throw new IndexOutOfBoundsException();
        }
    }
    
    public void guardarEnCSV(String ruta) throws IOException {
        try(BufferedWriter writer = new BufferedWriter(new FileWriter(ruta))) {
            for(T p : inventario) {
                writer.write(p.toCSV());
                writer.newLine();
            }
        }
    }

    public void cargarDesdeCSV(String ruta, Function<String, T> factory) throws IOException {
        inventario.clear();
        try(BufferedReader reader = new BufferedReader(new FileReader(ruta))) {
            String linea;
            while((linea = reader.readLine()) != null) {
                inventario.add(factory.apply(linea));
            }
        }
    }
    
    public void guardarEnArchivo(String ruta) throws IOException {
        try(ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ruta))) {
            oos.writeObject(inventario);
        }
    }
    
    public void cargarDesdeArchivo(String ruta) throws IOException, ClassNotFoundException {
        try(ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ruta))) {
            inventario = (List<T>) ois.readObject();
        }
    }
    
    
}
