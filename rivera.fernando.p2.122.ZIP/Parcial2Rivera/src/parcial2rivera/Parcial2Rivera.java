
package parcial2rivera;

import java.io.IOException;
import model.ColeccionPersonajes;
import model.Personaje;
import model.RolPersonaje;


public class Parcial2Rivera {

    
    public static void main(String[] args) {
        
        try{
            ColeccionPersonajes<Personaje> coleccion = new ColeccionPersonajes<>();
            coleccion.agregar(new Personaje(1, "Arthas", "Blizzard", RolPersonaje.TANQUE)); 
            coleccion.agregar(new Personaje(2, "Zelda Mage", "Nintendo", RolPersonaje.MAGO)); 
            coleccion.agregar(new Personaje(3, "Shadow Archer", "Sega", RolPersonaje.ARQUERO)); 
            coleccion.agregar(new Personaje(4, "MedBot 2.0", "Valve", RolPersonaje.SANADOR)); 
            coleccion.agregar(new Personaje(5, "Tech Engineer", "Capcom", RolPersonaje.INGENIERO));

            // Mostrar todos los personajes System.out.println("Personajes:");
            coleccion.paraCadaElemento(p -> System.out.println(p));


            // Filtrar por rol MAGO 
            System.out.println("\nPersonajes MAGO:");
            coleccion.filtrar(p -> p.getRol() == RolPersonaje.MAGO).forEach(p -> System.out.println(p));


            // Filtrar por nombre que contenga "Shadow" 
            System.out.println("\nPersonajes que contienen 'Shadow':");
            coleccion.filtrar(p -> p.getNombre().contains("Shadow")).forEach(p -> System.out.println(p));

            // Ordenar por ID (orden natural) 
            System.out.println("\nPersonajes ordenados por ID:");
            coleccion.ordenar();
            coleccion.paraCadaElemento(p -> System.out.println(p));

            // Ordenar personajes por nombre 
            System.out.println("\nPersonajes ordenados por nombre:");
            coleccion.ordenar((p1, p2) -> p1.getNombre().compareTo(p2.getNombre()));
            coleccion.paraCadaElemento(p -> System.out.println(p));

            // Guardar en archivo binario
            coleccion.guardarEnArchivo("src/data/personajes.dat");

            // Cargar desde archivo binario
            ColeccionPersonajes<Personaje> cargado = new ColeccionPersonajes<>();
            cargado.cargarDesdeArchivo("src/data/personajes.dat");
            System.out.println("\nPersonajes cargados desde archivo binario:");
            cargado.paraCadaElemento(p -> System.out.println(p));

            // Guardar en archivo CSV
            coleccion.guardarEnCSV("src/data/personajes.csv");

            // Cargar desde archivo CSV
            cargado.cargarDesdeCSV("src/data/personajes.csv", Personaje::fromCSV);
            System.out.println("\nPersonajes cargados desde archivo CSV:");
            cargado.paraCadaElemento(p -> System.out.println(p));
        
        }catch (IOException | ClassNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
